#Project description
This is a database project focused on reorganization and data management support.

##Technologies used
Docker Desktop, pgAdmin4, and Excel were used in this test.

##Database engine
pgAdmin4

##Explanation of the normalization process
At first glance, we see multiple redundancies, repetitions, and misspelled names.
We will begin by breaking them down and removing redundancies; the best solution is to fragment them so that we can implement controlled repetitions.
------
ENTITY #1: RIWI-CLIENT
Attributes: Riwi-id, client, city

###Sub-entity: cities
-Attributes: Riwi-c, city
--------
ENTITY #2: RIWI-REPRESENTATIVES
Attributes: Riwi-2id, technician, branch

###Sub-entity: Riwi-branch
-Attributes: Riwi-B, Branch
-----------
ENTITY #3: RIWI-Equipment
Attributes: Riwi-3id, Equipment, category

###Sub-entity: Riwi-Equipment Category
-Attributes: Riwi-EC, Category
-----------
ENTITY #4: RIWI-BILL
Attributes: Work_Order, Service_Date, Service_type, Riwi-id,
Riwi-2id, Riwi-3id, Hours, cost
###Sub-entity: Riwi-Service_type
-Attributes: Riwi-ST, servicetype

This model provides us with controlled repetitions to keep everything more organized.
Thanks to these controlled repetitions, we can understand that even if certain names or items recur, we can distinguish that they do not originate from the same place, or that they belong to different locations or different representatives.

##Database structure

RIWI-BILL
     |-----------------------Riwi-Service_type
     |----RIWI-CLIENT
     |          |-------------Riwi-cities 
     |
     |----RIWI-REPRESENTATIVES
     |          |--------------Riwi-branch
     |
     |-----RIWI-EQUIPMENT
     |          |--------------Riwi-Equipmente Category

##Database creation instructions
The creation process essentially involves fragmenting the provided data, allowing for controlled repetitions while also resulting in a much more organized appearance.

##Developer information:
        ◦ Full name:Angel_David_Arnache_Cantillo
        ◦ Clan:Cayena